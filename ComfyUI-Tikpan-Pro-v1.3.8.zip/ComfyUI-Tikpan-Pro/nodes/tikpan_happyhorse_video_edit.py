"""
🐴 Tikpan：HappyHorse 1.0 Video-Edit 视频编辑节点（商业稳定版）
模型：happyhorse-1.0-video-edit
功能：自然语言指令编辑视频，可参考最多5张图片局部或全局编辑视频元素，
      精准复刻视频动态过程，实现更强表现能力

API 端点（中转站 tikpan.com）：
  - 提交任务：POST /alibailian/api/v1/services/aigc/video-generation/video-synthesis
  - 查询任务：GET /alibailian/api/v1/tasks/{task_id}

支持：
- 视频输入（URL 或本地视频自动上传）
- 参考图片输入（最多5张，自动上传获取 URL）
- 手动输入图片 URL
- 同步 / 异步双模式
- 完整重试、容错、进度反馈
- 视频自动下载到 ComfyUI 输出目录
"""

from .tikpan_categories import CATEGORY_VIDEO
import json
import time
import os
import re
import requests
import urllib3
import numpy as np
import traceback
from io import BytesIO
from PIL import Image
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import comfy.utils
import comfy.model_management
import folder_paths
from .tikpan_happyhorse_common import (
    extract_error_message,
    extract_task_output,
    extract_task_status,
    extract_video_url,
    is_failure_status,
    is_success_status,
    normalize_resolution,
    video_from_path,
)
from .tikpan_node_options import API_HOST_OPTIONS, normalize_api_host, VIDEO_DURATION_OPTIONS, WATERMARK_OPTIONS, normalize_seed, option_int, pick

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "https://tikpan.com"

# ------------------------------------------------------------------
# 通用工具
# ------------------------------------------------------------------

def safe_filename(text: str, max_len=60) -> str:
    """生成安全的文件名（仅保留字母数字、下划线、连字符、点）"""
    text = re.sub(r'[^\w\-_\.]', '_', str(text))
    if len(text) > max_len:
        text = text[:max_len]
    return text.strip('_')


def ensure_unique_path(path: str) -> str:
    """若文件已存在，添加序号避免覆盖"""
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    counter = 1
    while os.path.exists(f"{base}_{counter}{ext}"):
        counter += 1
    return f"{base}_{counter}{ext}"


def create_retry_session(retries=5, backoff=0.5, status_forcelist=None):
    """创建带自动重试的 requests 会话"""
    if status_forcelist is None:
        status_forcelist = [500, 502, 503, 504]
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=status_forcelist,
        allowed_methods=["GET", "POST"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def normalize_params(resolution, watermark, seed):
    """参数规范化：分辨率小写、水印布尔、种子可选"""
    resolution_api = normalize_resolution(resolution)
    watermark_api = True if watermark else False
    seed_api = normalize_seed(seed, default=888888)
    return resolution_api, watermark_api, seed_api


def friendly_error(status_code, body=""):
    """用户友好的错误提示"""
    messages = {
        401: "密钥无效，请检查 API 密钥或前往 https://tikpan.com 获取",
        402: "账号余额不足，请前往 https://tikpan.com 充值",
        403: "无权访问该资源，请检查密钥权限",
        429: "请求过于频繁，系统已自动等待并重试，请稍候",
    }
    if status_code in messages:
        return messages[status_code]
    return f"服务器返回错误 {status_code}，响应内容：{body[:300]}"


# ------------------------------------------------------------------
# Video-Edit 主节点（优化版）
# ------------------------------------------------------------------

class TikpanHappyHorseVideoEditNode:
    """
    HappyHorse 1.0 Video-Edit 视频编辑节点（商业稳定版）
    支持视频 + 参考图片 + 自然语言指令，实现精准的视频编辑
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "💰_福利_💰": (["🔥 0.6元RMB兑1虚拟美元余额 | 全网底价 👉 https://tikpan.com"],),
                "获取密钥请访问": (["👉 https://tikpan.com (官方授权Key获取点)"],),
                "API_密钥": ("STRING", {"default": os.environ.get("TIKPAN_API_KEY", "sk-"), "tooltip": "Tikpan 平台的 API 密钥，以 sk- 开头，从 https://tikpan.com 获取"}),
                "编辑指令": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "将背景替换为日落海滩，保持人物动作不变，添加暖色调滤镜",
                        "tooltip": "告诉 AI 怎么改这段视频，例如『换背景』『改色调』",
                    },
                ),
                "执行方式": (
                    ["同步 (等待生成并下载)", "异步 (仅提交任务)"],
                    {"default": "同步 (等待生成并下载)", "tooltip": "同步=直接等到出片；异步=只提交任务，配合『异步任务查询』节点取结果"},
                ),
                "清晰度": (
                    ["720P", "1080P"],
                    {"default": "1080P", "tooltip": "视频分辨率：1080P 更清晰但更慢更贵"},
                ),
                "视频时长": (VIDEO_DURATION_OPTIONS, {"default": "5秒｜5", "tooltip": "生成视频的秒数；越长越慢越贵"}),
                "水印": (
                    WATERMARK_OPTIONS,
                    {"default": "无水印", "tooltip": "是否在视频右下角加官方水印"},
                ),
                "随机种子": (
                    "INT",
                    {"default": 888888, "min": 0, "max": 2147483647, "tooltip": "同种子+同提示词可复现视频；改种子可换不同结果"},
                ),
                "最长等待秒数": (
                    "INT",
                    {"default": 600, "min": 30, "max": 3600, "step": 10, "tooltip": "等待视频生成完成的最长秒数；1080P/长视频建议加大"},
                ),
                "查询间隔秒数": (
                    "INT",
                    {"default": 10, "min": 5, "max": 60, "step": 5, "tooltip": "轮询任务状态的间隔秒数"},
                ),
            },
            "optional": {
                "中转站地址": (API_HOST_OPTIONS, {"default": API_HOST_OPTIONS[0], "tooltip": "Tikpan 中转站地址，一般保持默认即可"}),
                "视频URL": (
                    "STRING",
                    {
                        "multiline": False,
                        "default": "",
                        "tooltip": "输入视频的公开 URL（推荐），或留空上传本地视频",
                    },
                ),
                "本地视频": (
                    "VIDEO",
                    {"tooltip": "本地视频文件，将自动上传（视频较大可能耗时较长）"},
                ),
                "参考图1": ("IMAGE", {"tooltip": "参考图片1（可选，最多5张）"}),
                "参考图2": ("IMAGE", {"tooltip": "参考图片2（可选）"}),
                "参考图3": ("IMAGE", {"tooltip": "参考图片3（可选）"}),
                "参考图4": ("IMAGE", {"tooltip": "参考图片4（可选）"}),
                "参考图5": ("IMAGE", {"tooltip": "参考图片5（可选）"}),
                "参考图URL列表": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "多行输入，每行一个图片URL（优先级高于图片输入，最多5张）",
                    },
                ),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "VIDEO")
    RETURN_NAMES = ("📁_本地保存路径", "🆔_任务ID", "🔗_视频云端链接", "📄_完整日志", "🎬_视频输出")
    OUTPUT_NODE = True
    FUNCTION = "generate_video"
    CATEGORY = CATEGORY_VIDEO
    DESCRIPTION = "📝 HappyHorse 1.0 视频编辑：输入原视频 + 编辑指令 + 最多 5 张参考图，AI 重绘原视频。适合改背景、改色调、换主体、动作微调。"

    # ---------- 视频处理 ----------

    def upload_video(self, session, api_key, video_path, pbar):
        """上传本地视频，返回 URL，并更新进度条"""
        video_filename = os.path.basename(video_path)
        ext = os.path.splitext(video_filename)[1].lower()
        mime_types = {
            '.mp4': 'video/mp4',
            '.mov': 'video/quicktime',
            '.avi': 'video/x-msvideo',
            '.mkv': 'video/x-matroska',
            '.webm': 'video/webm',
        }
        mime_type = mime_types.get(ext, 'video/mp4')

        try:
            with open(video_path, 'rb') as f:
                video_bytes = f.read()
        except Exception as e:
            raise RuntimeError(f"读取视频文件失败: {e}")

        size_mb = len(video_bytes) / (1024 * 1024)
        print(f"[HappyHorse-VideoEdit] 📊 视频大小: {size_mb:.1f} MB", flush=True)
        if size_mb > 100:
            print("[HappyHorse-VideoEdit] ⚠️ 视频较大，上传可能需要较长时间...", flush=True)

        # 更新进度条（上传开始）
        if pbar:
            pbar.update_absolute(2, 100)

        upload_headers = {"Authorization": f"Bearer {api_key}"}
        files = {"file": (video_filename, video_bytes, mime_type)}
        upload_endpoints = [
            f"{base_url}/alibailian/api/v1/upload",
            f"{base_url}/v1/upload",
            f"{base_url}/upload",
        ]

        last_error = None
        for upload_url in upload_endpoints:
            try:
                print(f"[HappyHorse-VideoEdit] 🔄 上传视频到: {upload_url}", flush=True)
                resp = session.post(
                    upload_url,
                    headers=upload_headers,
                    files=files,
                    timeout=600,
                    verify=False,
                )

                if resp.status_code == 429:
                    print("[HappyHorse-VideoEdit] ⚠️ 上传限流(429)，等待后重试...", flush=True)
                    time.sleep(5)
                    continue

                if resp.status_code == 200:
                    res_json = resp.json()
                    url = (
                        res_json.get("url")
                        or (res_json.get("data") or {}).get("url")
                        or res_json.get("filename")
                    )
                    if url:
                        if not url.startswith("http"):
                            base_url = getattr(self, "api_base_url", BASE_URL)
                            url = f"{base_url}/{url.lstrip('/')}"
                        print(f"[HappyHorse-VideoEdit] ✅ 视频上传成功: {url[:80]}", flush=True)
                        if pbar:
                            pbar.update_absolute(5, 100)  # 上传完成，进度到 5%
                        return url
                    else:
                        last_error = f"上传成功但未返回URL: {json.dumps(res_json, ensure_ascii=False)[:200]}"
                        continue
                else:
                    last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                    continue

            except Exception as e:
                last_error = f"连接异常: {e}"
                continue

        raise RuntimeError(
            f"❌ 视频上传失败（尝试了 {len(upload_endpoints)} 个端点）。\n"
            f"最后错误: {last_error}\n"
            f"建议：将视频手动上传到公开存储，然后使用「视频URL」输入框填入链接。"
        )

    def get_video_url(self, session, api_key, video_url_input, local_video, pbar):
        """
        获取视频 URL：优先使用手动 URL，否则上传本地视频
        """
        # 1. 手动 URL 优先
        if video_url_input and video_url_input.strip():
            url = video_url_input.strip()
            if url.startswith("http"):
                print("[HappyHorse-VideoEdit] 🎬 使用手动提供的视频 URL", flush=True)
                if pbar:
                    pbar.update_absolute(5, 100)
                return url
            else:
                print("[HappyHorse-VideoEdit] ⚠️ 视频 URL 格式不正确，将忽略并尝试上传本地视频", flush=True)

        # 2. 上传本地视频（增强容错）
        if local_video is not None:
            # 兼容 ComfyUI VIDEO 类型的多种输出格式
            if isinstance(local_video, (list, tuple)):
                video_path = local_video[0]
            elif isinstance(local_video, str):
                video_path = local_video
            else:
                video_path = str(local_video)

            if video_path and os.path.exists(video_path):
                print("[HappyHorse-VideoEdit] 📤 正在上传本地视频...", flush=True)
                return self.upload_video(session, api_key, video_path, pbar)
            else:
                raise ValueError(f"视频文件不存在: {video_path}")

        raise ValueError("❌ 必须提供「视频URL」或「本地视频」")

    # ---------- 图片处理 ----------

    def tensor_to_pil(self, img_tensor):
        arr = 255.0 * img_tensor[0].cpu().numpy()
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        return Image.fromarray(arr).convert("RGB")

    def upload_single_image(self, session, api_key, img_tensor, index, pbar, total_images, completed):
        """上传单张参考图片，返回 URL"""
        try:
            pil_img = self.tensor_to_pil(img_tensor)
            buf = BytesIO()
            pil_img.save(buf, format="JPEG", quality=95)
            img_bytes = buf.getvalue()
        except Exception as e:
            raise RuntimeError(f"参考图{index}转换失败: {e}")

        size_mb = len(img_bytes) / (1024 * 1024)
        if size_mb > 10:
            raise RuntimeError(f"参考图{index}过大 ({size_mb:.1f}MB)，请压缩后重试（建议≤10MB）")

        upload_headers = {"Authorization": f"Bearer {api_key}"}
        files = {"file": (f"ref_{index}.jpg", img_bytes, "image/jpeg")}
        upload_endpoints = [
            f"{base_url}/alibailian/api/v1/upload",
            f"{base_url}/v1/upload",
            f"{base_url}/upload",
        ]

        last_error = None
        for upload_url in upload_endpoints:
            try:
                print(f"[HappyHorse-VideoEdit] 🔄 上传参考图{index} 到: {upload_url}", flush=True)
                resp = session.post(
                    upload_url,
                    headers=upload_headers,
                    files=files,
                    timeout=120,
                    verify=False,
                )

                if resp.status_code == 429:
                    time.sleep(5)
                    continue

                if resp.status_code == 200:
                    res_json = resp.json()
                    url = (
                        res_json.get("url")
                        or (res_json.get("data") or {}).get("url")
                        or res_json.get("filename")
                    )
                    if url:
                        if not url.startswith("http"):
                            base_url = getattr(self, "api_base_url", BASE_URL)
                            url = f"{base_url}/{url.lstrip('/')}"
                        print(f"[HappyHorse-VideoEdit] ✅ 参考图{index}上传成功", flush=True)
                        # 更新进度
                        completed[0] += 1
                        if pbar and total_images > 0:
                            progress = 5 + int(5 * completed[0] / total_images)
                            pbar.update_absolute(min(progress, 10), 100)
                        return url
                    else:
                        last_error = f"上传成功但未返回URL: {json.dumps(res_json, ensure_ascii=False)[:200]}"
                        continue
                else:
                    last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                    continue

            except Exception as e:
                last_error = f"连接异常: {e}"
                continue

        raise RuntimeError(
            f"❌ 参考图{index}上传失败（尝试了 {len(upload_endpoints)} 个端点）。\n"
            f"最后错误: {last_error}\n"
            f"建议：将图片手动上传到公开图床，然后使用「参考图URL列表」输入框填入链接。"
        )

    def get_reference_urls(self, session, api_key, img_tensors, manual_urls, pbar):
        """获取所有参考图片的 HTTP URL，优先使用手动 URL"""
        urls = []
        completed = [0]  # 可变对象用于回调更新计数

        # 1. 解析手动 URL 列表（最多5张）
        if manual_urls:
            lines = [l.strip() for l in manual_urls.strip().split('\n') if l.strip()]
            for i, url in enumerate(lines, 1):
                if url.startswith("http"):
                    urls.append(url)
                    print(f"[HappyHorse-VideoEdit] 🖼️ 手动参考URL {len(urls)}: {url[:60]}", flush=True)
                else:
                    print(f"[HappyHorse-VideoEdit] ⚠️ 第{i}行URL格式不正确: {url}", flush=True)

            if len(urls) >= 5:
                print("[HappyHorse-VideoEdit] ℹ️ 手动URL已满5张，不再上传本地图片", flush=True)
                if pbar:
                    pbar.update_absolute(10, 100)
                return urls[:5]

        # 2. 收集需要上传的图片（参考图1-5）
        to_upload = []
        for i in range(1, 6):
            key = f"参考图{i}"
            if key in img_tensors and img_tensors[key] is not None:
                to_upload.append((i, img_tensors[key]))

        remaining = min(5 - len(urls), len(to_upload))
        if remaining > 0:
            print(f"[HappyHorse-VideoEdit] 📤 准备上传 {remaining} 张参考图", flush=True)

        # 3. 上传（带进度）
        for idx, (img_index, img_tensor) in enumerate(to_upload[:remaining], 1):
            try:
                url = self.upload_single_image(
                    session, api_key, img_tensor, img_index,
                    pbar, total_images=remaining, completed=completed
                )
                urls.append(url)
            except Exception as e:
                print(f"[HappyHorse-VideoEdit] ⚠️ 忽略参考图{img_index}: {e}", flush=True)

        # 确保进度至少到10%（边界情况保护）
        if pbar:
            pbar.update_absolute(10, 100)

        print(f"[HappyHorse-VideoEdit] 📊 最终使用 {len(urls)} 张参考图片", flush=True)
        return urls

    # ---------- 任务提交 ----------

    def submit_task(self, session, api_key, prompt, video_url, reference_urls, resolution, duration, watermark, seed):
        base_url = getattr(self, "api_base_url", BASE_URL)
        url = f"{base_url}/alibailian/api/v1/services/aigc/video-generation/video-synthesis"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-DashScope-Async": "enable",
        }

        media_list = [{"type": "video", "url": video_url}]
        for ref_url in reference_urls:
            media_list.append({"type": "reference", "url": ref_url})

        payload = {
            "model": "happyhorse-1.0-video-edit",
            "input": {"prompt": prompt, "media": media_list},
            "parameters": {
                "resolution": resolution,
                "duration": duration,
                "watermark": watermark,
            },
        }
        if seed is not None:
            payload["parameters"]["seed"] = seed

        print(f"[HappyHorse-VideoEdit] 🚀 提交视频编辑任务（视频+{len(reference_urls)}张参考图）...", flush=True)
        try:
            resp = session.post(url, headers=headers, json=payload, timeout=180, verify=False)
            print(f"[HappyHorse-VideoEdit] 📥 响应状态: {resp.status_code}", flush=True)

            if resp.status_code == 429:
                return False, friendly_error(429)

            if resp.status_code != 200:
                return False, friendly_error(resp.status_code, resp.text[:1000])

            res_json = resp.json()
            task_id = (
                res_json.get("output", {}).get("task_id")
                or res_json.get("task_id")
                or res_json.get("request_id")
            )
            if not task_id:
                return False, f"响应中未找到 task_id: {json.dumps(res_json, ensure_ascii=False)[:600]}"

            print(f"[HappyHorse-VideoEdit] ✅ 任务已创建，ID: {task_id}", flush=True)
            return True, task_id

        except requests.exceptions.RequestException as e:
            return False, f"网络异常: {e}"
        except Exception as e:
            traceback.print_exc()
            return False, f"提交异常: {e}"

    # ---------- 轮询 ----------

    def poll_task(self, session, api_key, task_id, max_wait_seconds, poll_interval, pbar):
        base_url = getattr(self, "api_base_url", BASE_URL)
        url = f"{base_url}/alibailian/api/v1/tasks/{task_id}"
        headers = {"Authorization": f"Bearer {api_key}"}

        print(f"[HappyHorse-VideoEdit] 🔄 开始轮询（每 {poll_interval} 秒，最长 {max_wait_seconds}s）...", flush=True)
        start_time = time.time()
        poll_count = 0

        while time.time() - start_time < max_wait_seconds:
            poll_count += 1
            try:
                resp = session.get(url, headers=headers, timeout=30, verify=False)

                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After", str(poll_interval * 2))
                    wait = int(retry_after) if retry_after.isdigit() else poll_interval * 2
                    time.sleep(wait)
                    continue

                if resp.status_code != 200:
                    time.sleep(poll_interval)
                    continue

                res_json = resp.json()
                output = extract_task_output(res_json)
                task_status = extract_task_status(res_json)

                elapsed = int(time.time() - start_time)
                progress = 20 + min(elapsed / max_wait_seconds * 65, 65)
                if pbar:
                    pbar.update_absolute(int(progress), 100)

                if poll_count % 3 == 0 or is_success_status(task_status) or is_failure_status(task_status):
                    print(f"[HappyHorse-VideoEdit] ⏳ 轮询中... {elapsed}s, 状态: {task_status}", flush=True)

                if is_success_status(task_status):
                    video_url = extract_video_url(res_json)
                    if video_url:
                        print(f"[HappyHorse-VideoEdit] ✅ 任务完成！总耗时 {elapsed}s", flush=True)
                        return True, video_url, res_json
                    return False, "任务成功但未返回视频链接", res_json

                if is_failure_status(task_status):
                    err = extract_error_message(output)
                    return False, f"任务终止（{task_status}）: {err}", res_json

                time.sleep(poll_interval)

            except requests.exceptions.RequestException:
                time.sleep(poll_interval)

        return False, f"轮询超时（{max_wait_seconds}s）", {}

    # ---------- 下载 ----------

    def download_video(self, session, video_url, task_id, pbar):
        try:
            print("[HappyHorse-VideoEdit] 📥 正在下载视频...", flush=True)
            resp = session.get(video_url, timeout=600, stream=True, verify=False)
            resp.raise_for_status()

            out_dir = folder_paths.get_output_directory()
            safe_id = safe_filename(str(task_id))[:50]
            filename = f"HappyHorse_VideoEdit_{safe_id}.mp4"
            local_path = ensure_unique_path(os.path.join(out_dir, filename))

            total = int(resp.headers.get("content-length", 0))
            dl = 0
            with open(local_path, "wb") as f:
                for chunk in resp.iter_content(8192):
                    if chunk:
                        f.write(chunk)
                        dl += len(chunk)
                        if total and pbar:
                            dp = 85 + min(dl / total * 15, 15)
                            pbar.update_absolute(int(dp), 100)

            if os.path.getsize(local_path) == 0:
                os.remove(local_path)
                return False, "下载的视频文件为空"

            return True, local_path
        except Exception as e:
            return False, f"下载失败: {e}"

    # ---------- 主入口 ----------

    def generate_video(self, **kwargs):
        try:
            api_key = str(pick(kwargs, "API_密钥", "api_key", default="") or "").strip()
            self.api_base_url = normalize_api_host(pick(kwargs, "中转站地址", "api_host", default=API_HOST_OPTIONS[0]))
            prompt = str(pick(kwargs, "编辑指令", "prompt", default="") or "").strip()
            mode = str(pick(kwargs, "执行方式", "mode", default="同步 (等待生成并下载)") or "同步 (等待生成并下载)")
            resolution = str(pick(kwargs, "清晰度", "resolution", default="1080P") or "1080P")
            duration = option_int(pick(kwargs, "视频时长", "duration", default="5秒｜5"), default=5, minimum=3, maximum=15)
            watermark = pick(kwargs, "水印", "watermark", default="无水印") == "有水印"
            seed = normalize_seed(pick(kwargs, "随机种子", "seed", default=888888), default=888888)
            max_wait = int(pick(kwargs, "最长等待秒数", "max_wait_seconds", default=600) or 600)
            poll_int = int(pick(kwargs, "查询间隔秒数", "poll_interval", default=10) or 10)
            video_url_input = str(kwargs.get("视频URL") or "").strip()
            manual_ref_urls = str(kwargs.get("参考图URL列表") or "").strip()
            local_video = kwargs.get("本地视频")

            img_tensors = {}
            for i in range(1, 6):
                key = f"参考图{i}"
                if key in kwargs and kwargs[key] is not None:
                    img_tensors[key] = kwargs[key]

            is_async = mode.startswith("异步")

            if not api_key or len(api_key) < 10:
                return ("", "", "", "❌ 请填写有效的 API 密钥", None)
            if not prompt:
                return ("", "", "", "❌ 编辑指令不能为空", None)
            if not (3 <= duration <= 15):
                return ("", "", "", "❌ 时长需在 3–15 秒之间", None)
            if not video_url_input and not local_video:
                return ("", "", "", "❌ 至少需要提供「视频URL」或「本地视频」", None)

            # 规范化参数（分辨率转小写等）
            res_norm, watermark_norm, seed_norm = normalize_params(resolution, watermark, seed)

            print(f"\n{'='*60}", flush=True)
            print("[HappyHorse-VideoEdit] 🎬 HappyHorse 1.0 Video-Edit 视频编辑", flush=True)
            print(f"[HappyHorse-VideoEdit] 📝 指令: {prompt[:100]}", flush=True)
            print(f"[HappyHorse-VideoEdit] 📐 {res_norm} | ⏱️ {duration}s | 水印:{'开启' if watermark_norm else '关闭'} | Seed:{seed_norm}", flush=True)
            print(f"[HappyHorse-VideoEdit] 🎛️ 模式: {mode}", flush=True)

            session = create_retry_session()
            pbar = comfy.utils.ProgressBar(100)
            pbar.update_absolute(0, 100)

            # 1. 视频 URL (0% → 5%)
            comfy.model_management.throw_exception_if_processing_interrupted()
            try:
                video_url = self.get_video_url(session, api_key, video_url_input, local_video, pbar)
            except Exception as e:
                return ("", "", "", f"❌ 获取视频URL失败: {e}", None)

            # 2. 参考图片 URLs (5% → 10%)
            comfy.model_management.throw_exception_if_processing_interrupted()
            try:
                reference_urls = self.get_reference_urls(session, api_key, img_tensors, manual_ref_urls, pbar)
            except Exception as e:
                return ("", "", "", f"❌ 获取参考图片URL失败: {e}", None)

            # 3. 提交任务 (10% → 20%)
            comfy.model_management.throw_exception_if_processing_interrupted()
            success, result = self.submit_task(
                session, api_key, prompt, video_url, reference_urls,
                res_norm, duration, watermark_norm, seed_norm
            )
            if not success:
                return ("", "", "", f"❌ 提交失败: {result}", None)

            task_id = result
            pbar.update_absolute(20, 100)

            if is_async:
                log = (
                    f"✅ 异步任务已提交\n"
                    f"🆔 任务 ID: {task_id}\n"
                    f"📁 本地文件尚未生成，请使用「🔍 Tikpan：异步任务查询与下载」获取结果\n"
                    f"📐 分辨率: {res_norm}\n"
                    f"⏱️ 时长: {duration}s\n"
                )
                pbar.update_absolute(100, 100)
                return ("", task_id, "", log, None)

            # 4. 轮询 (20% → 85%)
            comfy.model_management.throw_exception_if_processing_interrupted()
            poll_ok, poll_res, poll_data = self.poll_task(
                session, api_key, task_id, max_wait, poll_int, pbar
            )
            if not poll_ok:
                return ("", task_id, "", f"❌ 任务执行失败: {poll_res}\n{json.dumps(poll_data, ensure_ascii=False)[:1000]}", None)

            video_url_result = poll_res
            pbar.update_absolute(85, 100)

            # 5. 下载 (85% → 100%)
            comfy.model_management.throw_exception_if_processing_interrupted()
            dl_ok, dl_res = self.download_video(session, video_url_result, task_id, pbar)
            pbar.update_absolute(100, 100)

            usage = poll_data.get("usage", {})
            log_msg = (
                f"✅ 视频编辑成功\n"
                f"🆔 任务 ID: {task_id}\n"
                f"{'📁 本地: ' + dl_res if dl_ok else '⚠️ 下载失败: ' + dl_res}\n"
                f"🔗 {video_url_result}\n"
                f"📝 指令: {prompt[:50]}...\n"
                f"🖼️ 参考图: {len(reference_urls)}张\n"
                f"📐 {res_norm} | ⏱️ {duration}s | 🏷️ {'有水印' if watermark_norm else '无水印'}\n"
                f"📊 实际: {usage.get('output_video_duration','-')}s {usage.get('SR','-')}P\n"
                f"\n📄 完整响应:\n{json.dumps(poll_data, ensure_ascii=False, indent=2)[:2000]}"
            )
            video_output = video_from_path(dl_res) if dl_ok else None
            return (dl_res if dl_ok else "", task_id, video_url_result, log_msg, video_output)

        except Exception as e:
            tb = traceback.format_exc()
            print(f"[HappyHorse-VideoEdit] ❌ 严重错误: {e}\n{tb}", flush=True)
            return ("", "", "", f"❌ 严重错误: {e}\n{tb[:2000]}", None)


# ------------------------------------------------------------------
# 节点注册
# ------------------------------------------------------------------
NODE_CLASS_MAPPINGS = {
    "TikpanHappyHorseVideoEditNode": TikpanHappyHorseVideoEditNode,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "TikpanHappyHorseVideoEditNode": "🐴 Tikpan：HappyHorse 1.0 Video-Edit 视频编辑",
}
